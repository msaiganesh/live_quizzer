A Pen created at CodePen.io. You can find this one at http://codepen.io/boudra/pen/YXzLBN.

 A simple animated login form