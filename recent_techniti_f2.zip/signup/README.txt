A Pen created at CodePen.io. You can find this one at http://codepen.io/palimadra/pen/DnHuB.

 Based on Andreas Storm's design.