/* 
  Based on Andreas Storm work
  URL: http://codepen.io/andreasstorm/pen/duBpt
*/