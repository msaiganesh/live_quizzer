<link href="css/bootstrap.css" rel="stylesheet">

<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/jquery.validate.js"></script>
<script>
    $(document).ready(function(){
       // alert();
        $('#myform').validate();
    })
</script>